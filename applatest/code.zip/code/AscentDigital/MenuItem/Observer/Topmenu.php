<?php
 
namespace AscentDigital\MenuItem\Observer;
    use Magento\Framework\Event\Observer as EventObserver;
    use Magento\Framework\Data\Tree\Node;
    use Magento\Framework\Event\ObserverInterface;
 
    class Topmenu implements ObserverInterface
    {
        public function __construct()
        {
        }
 
        public function execute(EventObserver $observer)
        {
        
            $reportingUrl="";
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
            $baseUrl = $storeManager->getStore()->getBaseUrl();
            
            if($storeManager->getStore()->getId()==2){
                $reportingUrl="asd";
                $returnUrl=$baseUrl.'returns';
                $returnTitle= 'Returns';
            }else{
                $returnUrl=$baseUrl.'advanceexchange';
                $reportingUrl=$baseUrl.'reporting';  
                $returnTitle = 'Depot Services';
            }
            $menu = $observer->getMenu();
            $tree = $menu->getTree();
        //information top menu code
            $data = ['name' => __('Information'),
                'id' => 'information',
                'url' => $baseUrl.'nsconnector/information/information',
                'is_active' => false];
            $node = new Node($data, 'id', $tree, $menu);
            $menu->addChild($node);
        //retun top menu code
            $data = ['name' => __($returnTitle),
            'id' => 'returns',
            'url' => $returnUrl,
            'is_active' => false];
            $node = new Node($data, 'id', $tree, $menu);
            $menu->addChild($node);
        //reporting top menu code    
            $data = ['name' => __('Reporting'),
            'id' => 'reporting',
            'url' => $reportingUrl,
            'is_active' => false];
            $node = new Node($data, 'id', $tree, $menu);
            $menu->addChild($node);
            return $this;
        }
    }