<?php
namespace AscentDigital\NetsuiteConnector\Block\Adminhtml\Cron;

class AdvanceExchangeTab extends \Magento\Backend\Block\Template
{
   /**
    * Block template.
    *
    * @var string
    */
   protected $_template = 'tab/advance_exchange_tab.phtml';

}