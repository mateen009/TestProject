<?php
namespace AscentDigital\NetsuiteConnector\Block\Adminhtml\Cron;

class DeletedProductTab extends \Magento\Backend\Block\Template
{
   /**
    * Block template.
    *
    * @var string
    */
   protected $_template = 'tab/deleted_product_tab.phtml';

}