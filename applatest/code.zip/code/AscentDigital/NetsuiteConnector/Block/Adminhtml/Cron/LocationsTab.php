<?php
namespace AscentDigital\NetsuiteConnector\Block\Adminhtml\Cron;

class LocationsTab extends \Magento\Backend\Block\Template
{
   /**
    * Block template.
    *
    * @var string
    */
   protected $_template = 'tab/locations_tab.phtml';

}