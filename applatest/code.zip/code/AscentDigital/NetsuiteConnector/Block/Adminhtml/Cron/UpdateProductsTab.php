<?php
namespace AscentDigital\NetsuiteConnector\Block\Adminhtml\Cron;

class UpdateProductsTab extends \Magento\Backend\Block\Template
{
   /**
    * Block template.
    *
    * @var string
    */
   protected $_template = 'tab/update_products_tab.phtml';

}