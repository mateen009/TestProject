<?php
namespace AscentDigital\NetsuiteConnector\Cron\Customer;
use AscentDigital\NetsuiteConnector\Helper\CSMPhone as MCGManager;


class CSMPhone
{
    /**
     * @var MCGManager;
     */
    protected $mcgManager;

    /**
     * @param MCGManager $mcgManager
     */
    public function __construct(
        MCGManager $mcgManager
    )
    {
        $this->mcgManager = $mcgManager;
    }

    
    public function execute()
    {
        die('cron');
        $this->mcgManager->getCSMPhone();
    }

    
}
