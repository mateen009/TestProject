var config = {
    map: {
        '*': {
            multiselect: 'AscentDigital_Reports/js/multiselect',
        }
    }
};