<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PerksAtWork_NextJumpSFTP',
    __DIR__
);
