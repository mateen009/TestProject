<?php
namespace AscentDigital\NetsuiteConnector\Block\Adminhtml\Cron;

class CustomerSpecificPricingTab extends \Magento\Backend\Block\Template
{
   /**
    * Block template.
    *
    * @var string
    */
   protected $_template = 'tab/customer_specific_pricing_tab.phtml';

}