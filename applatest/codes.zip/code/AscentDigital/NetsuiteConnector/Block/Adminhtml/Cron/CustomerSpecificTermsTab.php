<?php
namespace AscentDigital\NetsuiteConnector\Block\Adminhtml\Cron;

class CustomerSpecificTermsTab extends \Magento\Backend\Block\Template
{
   /**
    * Block template.
    *
    * @var string
    */
   protected $_template = 'tab/customer_specific_terms_tab.phtml';

}