<?php
namespace AscentDigital\NetsuiteConnector\Block\Adminhtml\Cron;

class ShippingCronTab extends \Magento\Backend\Block\Template
{
   /**
    * Block template.
    *
    * @var string
    */
   protected $_template = 'tab/shipping_cron_tab.phtml';

}