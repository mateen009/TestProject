<?php
use Magento\Framework\Component\ComponentRegistrar;
ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'AscentDigital_NetsuiteConnector',
    __DIR__
);