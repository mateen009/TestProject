<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace AscentDigital\OrderApproval\Block\Order;


/**
 * success message show block
 *
 */
class SuccessMessage extends \Magento\Framework\View\Element\Template
{
    
}

