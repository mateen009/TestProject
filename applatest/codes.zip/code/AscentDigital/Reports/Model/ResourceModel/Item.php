<?php
namespace AscentDigital\Reports\Model\ResourceModel;


class Item extends \Magento\Sales\Model\ResourceModel\Order\Item
{
}
