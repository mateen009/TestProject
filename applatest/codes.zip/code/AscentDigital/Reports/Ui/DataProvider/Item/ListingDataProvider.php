<?php
namespace AscentDigital\Reports\Ui\DataProvider\Item;


class ListingDataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider
{
}