<?php

 \Magento\Framework\Component\ComponentRegistrar::register(

\Magento\Framework\Component\ComponentRegistrar::THEME,

'adminhtml/Cg/Backend',

__DIR__

);