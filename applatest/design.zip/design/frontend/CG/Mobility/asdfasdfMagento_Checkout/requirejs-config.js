var config = {
    config: {
        mixins: {
            'mage/dropdown': {
                'Magento_Checkout/js/dropdown-mixin': true
            }
        }
    }
};