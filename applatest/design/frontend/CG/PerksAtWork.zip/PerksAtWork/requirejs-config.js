var config = {
    deps: [
        'js/custom'
    ]
};
