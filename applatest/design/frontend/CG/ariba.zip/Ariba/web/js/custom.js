define(['jquery', 'domReady!'], function ($) {
    $(".page-main").find(".category-view").each(function(){
        $(".page-wrapper").addClass("category-with-block");
    })
});
